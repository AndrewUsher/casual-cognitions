# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [3.0.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@3.0.0...gatsby-link@3.0.1) (2021-03-05)

**Note:** Version bump only for package gatsby-link

# [3.0.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@3.0.0-v3rc.1...gatsby-link@3.0.0) (2021-03-02)

**Note:** Version bump only for package gatsby-link

# [3.0.0-v3rc.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@3.0.0-v3rc.0...gatsby-link@3.0.0-v3rc.1) (2021-02-26)

### Bug Fixes

- **gatsby:** Use vendored @reach/router ([#29772](https://github.com/gatsbyjs/gatsby/issues/29772)) ([#29811](https://github.com/gatsbyjs/gatsby/issues/29811)) ([bd856ef](https://github.com/gatsbyjs/gatsby/commit/bd856efac1334b2385ced7ecb25c92e046882487))

# [3.0.0-v3rc.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@3.0.0-next.0...gatsby-link@3.0.0-v3rc.0) (2021-02-26)

**Note:** Version bump only for package gatsby-link

# [3.0.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.12.0-next.1...gatsby-link@3.0.0-next.0) (2021-02-05)

**Note:** Version bump only for package gatsby-link

# [2.12.0-next.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.12.0-next.0...gatsby-link@2.12.0-next.1) (2021-02-04)

**Note:** Version bump only for package gatsby-link

# [2.12.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.11.0-next.0...gatsby-link@2.12.0-next.0) (2021-01-28)

### Bug Fixes

- **deps:** update minor and patch for gatsby-link ([#29175](https://github.com/gatsbyjs/gatsby/issues/29175)) ([7e07e2b](https://github.com/gatsbyjs/gatsby/commit/7e07e2b748c0195fc4a1e2b442c6836338d906dd))

# [2.11.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.10.0-next.1...gatsby-link@2.11.0-next.0) (2021-01-18)

### Bug Fixes

- **security:** update vulnerable packages, include React 17 in peerDeps ([#28545](https://github.com/gatsbyjs/gatsby/issues/28545)) ([18b5f30](https://github.com/gatsbyjs/gatsby/commit/18b5f30e367895aa5f3af46e4989b347912a0f35))

# [2.10.0-next.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.10.0-next.0...gatsby-link@2.10.0-next.1) (2021-01-12)

**Note:** Version bump only for package gatsby-link

# [2.10.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.9.0-next.0...gatsby-link@2.10.0-next.0) (2020-12-29)

**Note:** Version bump only for package gatsby-link

# [2.9.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.8.0-next.0...gatsby-link@2.9.0-next.0) (2020-12-10)

**Note:** Version bump only for package gatsby-link

# [2.8.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.7.0-next.0...gatsby-link@2.8.0-next.0) (2020-11-26)

### Bug Fixes

- **gatsby-link:** don't prefetch same page ([#28307](https://github.com/gatsbyjs/gatsby/issues/28307)) ([3666130](https://github.com/gatsbyjs/gatsby/commit/36661308db47696a3b29d2348c190817d81f1595))

# [2.7.0-next.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.6.0-next.0...gatsby-link@2.7.0-next.0) (2020-11-18)

**Note:** Version bump only for package gatsby-link

# [2.5.0-next.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.5.0-next.0...gatsby-link@2.5.0-next.1) (2020-11-10)

**Note:** Version bump only for package gatsby-link

## [2.4.16](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.15...gatsby-link@2.4.16) (2020-10-20)

### Bug Fixes

- **deps:** update minor and patch for gatsby-link ([#27118](https://github.com/gatsbyjs/gatsby/issues/27118)) ([fc3b2d6](https://github.com/gatsbyjs/gatsby/commit/fc3b2d6cf6f85fd9a933bf850ff5970eb05234d9))

## [2.4.15](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.14...gatsby-link@2.4.15) (2020-09-28)

**Note:** Version bump only for package gatsby-link

## [2.4.14](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.13...gatsby-link@2.4.14) (2020-09-15)

**Note:** Version bump only for package gatsby-link

## [2.4.13](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.12...gatsby-link@2.4.13) (2020-07-15)

### Bug Fixes

- **gatsby:** Support numbers in navigate function ([#25611](https://github.com/gatsbyjs/gatsby/issues/25611)) ([83926c8](https://github.com/gatsbyjs/gatsby/commit/83926c8))
- **gatsby-link:** Do not crash in unit tests when globals are undefined ([#25608](https://github.com/gatsbyjs/gatsby/issues/25608)) ([6404fc7](https://github.com/gatsbyjs/gatsby/commit/6404fc7))

## [2.4.12](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.11...gatsby-link@2.4.12) (2020-07-09)

**Note:** Version bump only for package gatsby-link

## [2.4.11](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.10...gatsby-link@2.4.11) (2020-07-02)

**Note:** Version bump only for package gatsby-link

## [2.4.10](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.9...gatsby-link@2.4.10) (2020-07-01)

**Note:** Version bump only for package gatsby-link

## [2.4.9](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.8...gatsby-link@2.4.9) (2020-07-01)

**Note:** Version bump only for package gatsby-link

## [2.4.8](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.7...gatsby-link@2.4.8) (2020-06-24)

**Note:** Version bump only for package gatsby-link

## [2.4.7](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.6...gatsby-link@2.4.7) (2020-06-22)

**Note:** Version bump only for package gatsby-link

## [2.4.6](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.5...gatsby-link@2.4.6) (2020-06-09)

**Note:** Version bump only for package gatsby-link

## [2.4.5](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.4...gatsby-link@2.4.5) (2020-06-03)

### Bug Fixes

- **gatsby-link:** Fail gracefully on empty `to` prop ([#24745](https://github.com/gatsbyjs/gatsby/issues/24745)) ([700cff7](https://github.com/gatsbyjs/gatsby/commit/700cff7))

## [2.4.4](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.3...gatsby-link@2.4.4) (2020-06-02)

### Features

- **gatsby:** Add support for relative links ([#24054](https://github.com/gatsbyjs/gatsby/issues/24054)) ([e2c6cf2](https://github.com/gatsbyjs/gatsby/commit/e2c6cf2))

## [2.4.3](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.2...gatsby-link@2.4.3) (2020-05-20)

**Note:** Version bump only for package gatsby-link

## [2.4.2](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.1...gatsby-link@2.4.2) (2020-05-08)

### Bug Fixes

- **gatsby-link:** replace current path in history rather than pushing it ([#23414](https://github.com/gatsbyjs/gatsby/issues/23414)) ([5fcd6dc](https://github.com/gatsbyjs/gatsby/commit/5fcd6dc)), closes [#22124](https://github.com/gatsbyjs/gatsby/issues/22124)

## [2.4.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.4.0...gatsby-link@2.4.1) (2020-05-05)

**Note:** Version bump only for package gatsby-link

# [2.4.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.3.5...gatsby-link@2.4.0) (2020-04-27)

**Note:** Version bump only for package gatsby-link

## [2.3.5](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.3.4...gatsby-link@2.3.5) (2020-04-24)

**Note:** Version bump only for package gatsby-link

## [2.3.4](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.3.3...gatsby-link@2.3.4) (2020-04-17)

### Bug Fixes

- wrap ignore pattern in quotes ([#23176](https://github.com/gatsbyjs/gatsby/issues/23176)) ([7563db6](https://github.com/gatsbyjs/gatsby/commit/7563db6))

## [2.3.3](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.3.2...gatsby-link@2.3.3) (2020-04-16)

**Note:** Version bump only for package gatsby-link

## [2.3.2](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.3.1...gatsby-link@2.3.2) (2020-04-03)

### Bug Fixes

- **gatsby-link:** drop custom innerRef typing and reuse one from @reach/router ([#22770](https://github.com/gatsbyjs/gatsby/issues/22770)) ([14b9605](https://github.com/gatsbyjs/gatsby/commit/14b9605))

## [2.3.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.3.0...gatsby-link@2.3.1) (2020-03-23)

**Note:** Version bump only for package gatsby-link

# [2.3.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.31...gatsby-link@2.3.0) (2020-03-20)

**Note:** Version bump only for package gatsby-link

## [2.2.31](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.30...gatsby-link@2.2.31) (2020-03-16)

**Note:** Version bump only for package gatsby-link

## [2.2.30](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.29...gatsby-link@2.2.30) (2020-03-06)

**Note:** Version bump only for package gatsby-link

## [2.2.29](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.28...gatsby-link@2.2.29) (2020-02-01)

### Bug Fixes

- **gatsby-link:** Adds Type, PropType, tests, and docs for `st… ([#20807](https://github.com/gatsbyjs/gatsby/issues/20807)) ([d8937d0](https://github.com/gatsbyjs/gatsby/commit/d8937d0))

## [2.2.28](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.27...gatsby-link@2.2.28) (2020-01-09)

**Note:** Version bump only for package gatsby-link

## [2.2.27](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.25...gatsby-link@2.2.27) (2019-12-10)

**Note:** Version bump only for package gatsby-link

## [2.2.26](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.25...gatsby-link@2.2.26) (2019-12-10)

**Note:** Version bump only for package gatsby-link

## [2.2.25](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.24...gatsby-link@2.2.25) (2019-11-26)

**Note:** Version bump only for package gatsby-link

## [2.2.24](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.23...gatsby-link@2.2.24) (2019-11-15)

**Note:** Version bump only for package gatsby-link

## [2.2.23](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.22...gatsby-link@2.2.23) (2019-11-10)

**Note:** Version bump only for package gatsby-link

## [2.2.22](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.21...gatsby-link@2.2.22) (2019-10-14)

**Note:** Version bump only for package gatsby-link

## [2.2.21](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.20...gatsby-link@2.2.21) (2019-10-14)

**Note:** Version bump only for package gatsby-link

## [2.2.20](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.19...gatsby-link@2.2.20) (2019-10-10)

### Bug Fixes

- update dependency @types/reach\_\_router to ^1.2.6 ([#18405](https://github.com/gatsbyjs/gatsby/issues/18405)) ([6c37aa3](https://github.com/gatsbyjs/gatsby/commit/6c37aa3))

## [2.2.19](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.18...gatsby-link@2.2.19) (2019-10-09)

**Note:** Version bump only for package gatsby-link

## [2.2.18](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.17...gatsby-link@2.2.18) (2019-10-04)

**Note:** Version bump only for package gatsby-link

## [2.2.17](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.15...gatsby-link@2.2.17) (2019-09-26)

**Note:** Version bump only for package gatsby-link

## [2.2.16](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.15...gatsby-link@2.2.16) (2019-09-26)

**Note:** Version bump only for package gatsby-link

## [2.2.15](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.14...gatsby-link@2.2.15) (2019-09-20)

**Note:** Version bump only for package gatsby-link

## [2.2.14](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.13...gatsby-link@2.2.14) (2019-09-18)

### Bug Fixes

- update minor updates in packages except react, babel and eslint ([#17716](https://github.com/gatsbyjs/gatsby/issues/17716)) ([af39ae3](https://github.com/gatsbyjs/gatsby/commit/af39ae3))

## [2.2.13](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.12...gatsby-link@2.2.13) (2019-09-09)

**Note:** Version bump only for package gatsby-link

## [2.2.12](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.11...gatsby-link@2.2.12) (2019-09-04)

**Note:** Version bump only for package gatsby-link

## [2.2.11](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.10...gatsby-link@2.2.11) (2019-09-01)

### Bug Fixes

- update minor updates in packages except react, babel and eslint ([#17254](https://github.com/gatsbyjs/gatsby/issues/17254)) ([252d867](https://github.com/gatsbyjs/gatsby/commit/252d867))

## [2.2.10](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.9...gatsby-link@2.2.10) (2019-08-28)

**Note:** Version bump only for package gatsby-link

## [2.2.9](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.8...gatsby-link@2.2.9) (2019-08-24)

**Note:** Version bump only for package gatsby-link

## [2.2.8](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.7...gatsby-link@2.2.8) (2019-08-23)

**Note:** Version bump only for package gatsby-link

## [2.2.7](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.6...gatsby-link@2.2.7) (2019-08-22)

**Note:** Version bump only for package gatsby-link

## [2.2.6](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.5...gatsby-link@2.2.6) (2019-08-20)

### Bug Fixes

- update dependency [@types](https://github.com/types)/reach\_\_router to ^1.2.4 ([#16798](https://github.com/gatsbyjs/gatsby/issues/16798)) ([11b3f11](https://github.com/gatsbyjs/gatsby/commit/11b3f11))

## [2.2.5](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.4...gatsby-link@2.2.5) (2019-08-13)

**Note:** Version bump only for package gatsby-link

## [2.2.4](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.3...gatsby-link@2.2.4) (2019-07-30)

### Bug Fixes

- **docs:** change relative url to absolute url for gatsby-link readme ([#16197](https://github.com/gatsbyjs/gatsby/issues/16197)) ([3eb43db](https://github.com/gatsbyjs/gatsby/commit/3eb43db))

## [2.2.3](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.2...gatsby-link@2.2.3) (2019-07-25)

**Note:** Version bump only for package gatsby-link

## [2.2.2](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.1...gatsby-link@2.2.2) (2019-07-12)

### Bug Fixes

- correct links in package changelogs ([#15630](https://github.com/gatsbyjs/gatsby/issues/15630)) ([d07b9dd](https://github.com/gatsbyjs/gatsby/commit/d07b9dd))

## [2.2.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.2.0...gatsby-link@2.2.1) (2019-07-11)

**Note:** Version bump only for package gatsby-link

# [2.2.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.1.1...gatsby-link@2.2.0) (2019-06-20)

**Note:** Version bump only for package gatsby-link

## [2.1.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.1.0...gatsby-link@2.1.1) (2019-05-03)

### Bug Fixes

- **gatsby-link:** provide fallback for **BASE_PATH** being missing ([#13839](https://github.com/gatsbyjs/gatsby/issues/13839)) ([dc554bf](https://github.com/gatsbyjs/gatsby/commit/dc554bf))

# [2.1.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.17...gatsby-link@2.1.0) (2019-05-02)

### Features

- **gatsby:** add assetPrefix to support deploying assets separate from html ([#12128](https://github.com/gatsbyjs/gatsby/issues/12128)) ([8291044](https://github.com/gatsbyjs/gatsby/commit/8291044))

## [2.0.17](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.16...gatsby-link@2.0.17) (2019-04-30)

**Note:** Version bump only for package gatsby-link

## [2.0.16](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.15...gatsby-link@2.0.16) (2019-03-12)

### Features

- **gatsby-link:** adds support for partiallyActive=true to Link ([#12495](https://github.com/gatsbyjs/gatsby/issues/12495)) ([e0db681](https://github.com/gatsbyjs/gatsby/commit/e0db681))

## [2.0.15](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.14...gatsby-link@2.0.15) (2019-03-11)

**Note:** Version bump only for package gatsby-link

## [2.0.14](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.13...gatsby-link@2.0.14) (2019-03-04)

### Features

- **gatsby-link:** support RefObject ([#12174](https://github.com/gatsbyjs/gatsby/issues/12174)) ([5ab7a87](https://github.com/gatsbyjs/gatsby/commit/5ab7a87)), closes [#12014](https://github.com/gatsbyjs/gatsby/issues/12014)

## [2.0.13](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.12...gatsby-link@2.0.13) (2019-02-28)

**Note:** Version bump only for package gatsby-link

## [2.0.12](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.11...gatsby-link@2.0.12) (2019-02-22)

**Note:** Version bump only for package gatsby-link

## [2.0.11](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.10...gatsby-link@2.0.11) (2019-02-19)

**Note:** Version bump only for package gatsby-link

## [2.0.10](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.9...gatsby-link@2.0.10) (2019-02-01)

**Note:** Version bump only for package gatsby-link

<a name="2.0.9"></a>

## [2.0.9](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.8...gatsby-link@2.0.9) (2019-01-23)

**Note:** Version bump only for package gatsby-link

<a name="2.0.8"></a>

## [2.0.8](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.7...gatsby-link@2.0.8) (2019-01-10)

### Bug Fixes

- enable ref forwarding with forwardRef ([#9892](https://github.com/gatsbyjs/gatsby/issues/9892)) ([b6d9775](https://github.com/gatsbyjs/gatsby/commit/b6d9775))

<a name="2.0.7"></a>

## [2.0.7](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.6...gatsby-link@2.0.7) (2018-11-29)

**Note:** Version bump only for package gatsby-link

<a name="2.0.6"></a>

## [2.0.6](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.5...gatsby-link@2.0.6) (2018-10-29)

**Note:** Version bump only for package gatsby-link

<a name="2.0.5"></a>

## [2.0.5](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.4...gatsby-link@2.0.5) (2018-10-24)

**Note:** Version bump only for package gatsby-link

<a name="2.0.4"></a>

## [2.0.4](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.3...gatsby-link@2.0.4) (2018-10-03)

### Bug Fixes

- navigateTo deprecation message ([#8745](https://github.com/gatsbyjs/gatsby/issues/8745)) ([3c824f3](https://github.com/gatsbyjs/gatsby/commit/3c824f3))

<a name="2.0.3"></a>

## [2.0.3](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.2...gatsby-link@2.0.3) (2018-10-01)

**Note:** Version bump only for package gatsby-link

<a name="2.0.2"></a>

## [2.0.2](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.1...gatsby-link@2.0.2) (2018-09-26)

### Bug Fixes

- **gatsby-link:** use path prefix in navigate/replace/push calls ([#8289](https://github.com/gatsbyjs/gatsby/issues/8289)) ([df3ac18](https://github.com/gatsbyjs/gatsby/commit/df3ac18)), closes [#8155](https://github.com/gatsbyjs/gatsby/issues/8155)
- scroll behaviour when navigating back to anchor on the same page ([#8061](https://github.com/gatsbyjs/gatsby/issues/8061)) ([ef44cff](https://github.com/gatsbyjs/gatsby/commit/ef44cff))

<a name="2.0.1"></a>

## [2.0.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-rc.4...gatsby-link@2.0.1) (2018-09-17)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-rc.4"></a>

# [2.0.0-rc.4](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-rc.3...gatsby-link@2.0.0-rc.4) (2018-09-17)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-rc.3"></a>

# [2.0.0-rc.3](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-rc.2...gatsby-link@2.0.0-rc.3) (2018-09-13)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-rc.2"></a>

# [2.0.0-rc.2](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-rc.1...gatsby-link@2.0.0-rc.2) (2018-08-29)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-rc.1"></a>

# [2.0.0-rc.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-rc.0...gatsby-link@2.0.0-rc.1) (2018-08-29)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-rc.0"></a>

# [2.0.0-rc.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.22...gatsby-link@2.0.0-rc.0) (2018-08-21)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.22"></a>

# [2.0.0-beta.22](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.21...gatsby-link@2.0.0-beta.22) (2018-08-15)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.21"></a>

# [2.0.0-beta.21](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.20...gatsby-link@2.0.0-beta.21) (2018-08-15)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.20"></a>

# [2.0.0-beta.20](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.19...gatsby-link@2.0.0-beta.20) (2018-08-10)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.19"></a>

# [2.0.0-beta.19](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.18...gatsby-link@2.0.0-beta.19) (2018-08-09)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.18"></a>

# [2.0.0-beta.18](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.17...gatsby-link@2.0.0-beta.18) (2018-08-09)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.17"></a>

# [2.0.0-beta.17](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.15...gatsby-link@2.0.0-beta.17) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.15"></a>

# [2.0.0-beta.15](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.14...gatsby-link@2.0.0-beta.15) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.14"></a>

# [2.0.0-beta.14](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.12...gatsby-link@2.0.0-beta.14) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.12"></a>

# [2.0.0-beta.12](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.11...gatsby-link@2.0.0-beta.12) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.11"></a>

# [2.0.0-beta.11](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.10...gatsby-link@2.0.0-beta.11) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.10"></a>

# [2.0.0-beta.10](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.9...gatsby-link@2.0.0-beta.10) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.9"></a>

# [2.0.0-beta.9](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.8...gatsby-link@2.0.0-beta.9) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.8"></a>

# [2.0.0-beta.8](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.7...gatsby-link@2.0.0-beta.8) (2018-08-07)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.7"></a>

# [2.0.0-beta.7](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.6...gatsby-link@2.0.0-beta.7) (2018-08-06)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.6"></a>

# [2.0.0-beta.6](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.5...gatsby-link@2.0.0-beta.6) (2018-08-01)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.5"></a>

# [2.0.0-beta.5](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.4...gatsby-link@2.0.0-beta.5) (2018-07-21)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.4"></a>

# [2.0.0-beta.4](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.3...gatsby-link@2.0.0-beta.4) (2018-07-03)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.3"></a>

# [2.0.0-beta.3](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.2...gatsby-link@2.0.0-beta.3) (2018-06-25)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.2"></a>

# [2.0.0-beta.2](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.1...gatsby-link@2.0.0-beta.2) (2018-06-20)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.1"></a>

# [2.0.0-beta.1](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@2.0.0-beta.0...gatsby-link@2.0.0-beta.1) (2018-06-17)

**Note:** Version bump only for package gatsby-link

<a name="2.0.0-beta.0"></a>

# [2.0.0-beta.0](https://github.com/gatsbyjs/gatsby/compare/gatsby-link@1.6.44...gatsby-link@2.0.0-beta.0) (2018-06-17)

**Note:** Version bump only for package gatsby-link
